const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");


module.exports.run = async (bot, message, args) => {
  if (message.author.id == botconfig.OWNERID ) {
    console.log("{Owner}")
   let User = message.guild.member(message.mentions.users.first()) ||message.guild.members.cache.get(args[0])
    let target = message.guild.member(message.mentions.users.first())
    if (!User) return message.channel.send("Invalid User")
    let banReason = args.join(" ").slice(22);
    if (!banReason) {
      banReason = "None"
    }

    User.ban({reason: banReason})
    console.log("banned with reason",  banReason)
    message.react('👍')

  }
  else{

    if (!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send("Invalid Permissions")
    let User = message.guild.member(message.mentions.users.first()) ||message.guild.members.cache.get(args[0])
    let target = message.guild.member(message.mentions.users.first())
    if (!User) return message.channel.send("Invalid User")
    if (User.hasPermission("BAN_MEMBERS")) return message.reply("Invalid Permissions")
    let banReason = args.join(" ").slice(22);
    if (!banReason) {
      banReason = "None"
    }

    User.ban({reason: banReason})
    console.log("banned with reason",  banReason)
    message.react('👍')
    
}
}

module.exports.config = {
    name: "ban",
    description: "ban",
    usage: "?ban",
    accessableby: "all",
    aliases: []
}