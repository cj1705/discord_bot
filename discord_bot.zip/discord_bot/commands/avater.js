const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");
const talkedRecently = new Set();   
module.exports.run = async (bot, message, args) => {
    if (talkedRecently.has(message.author.id)) {

        
        message.reply(`Please wait 5 seconds.`);
} 
else {
    talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 5000);
        console.log(message.author.tag, "is now on a 5 second timeout")

    const embed = new Discord.MessageEmbed()

if(!message.mentions.users.first()) {
    embed.setTitle('Your avatar');
    embed.setColor(0x00008b);
    embed.setTimestamp();
    embed.setFooter(message.author.username);
    embed.setImage(message.author.displayAvatarURL({size: 2048, dynamic: true}));
    message.channel.send(embed);
} else {
    let user = message.mentions.users.first();
    embed.setTitle(`${user.username}'s avatar`);
    embed.setColor(0x8b0000);
    embed.setTimestamp();
    embed.setFooter(user.username);
    embed.setImage(bot.users.cache.get(user.id).displayAvatarURL({size: 2048, dynamic: true}));
    message.channel.send(embed);
}
}
}
module.exports.config = {
    name: "av",
    description: "av",
    usage: "?av",
    accessableby: "all",
    aliases: []
}