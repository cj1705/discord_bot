const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
const botsettings = require('../botsettings.json');

module.exports.run = async (bot, message, args) => {
} 

          
        
                
    
module.exports.config = {
    name: "test",
    description: "test",
    usage: "?test",
    accessableby: "members",
    aliases: []
}