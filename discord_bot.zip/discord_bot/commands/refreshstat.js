const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");


module.exports.run = async (bot, message, args) => {
    module.exports.run = async (bot, message, args) => {
        if (message.author.id == botconfig.OWNERID ) {
            if (!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send("Invalid Permissions")
    bot.user.setActivity( `Refreshing..` , {type: ""});
    bot.user.setActivity( `${prefix}help` , {type: ""});
    message.channel.send("Bot status has been refreshed")
    
        }
        else{
            message.reply("no")
    
 
    }
}
}




module.exports.config = {
    name: "rstat",
    description: "rstat",
    usage: "rstat",
    accessableby: "admins",
    aliases: []
}