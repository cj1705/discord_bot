const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");
const talkedRecently = new Set();  
const fs   = require('fs')  

module.exports.run = async (bot, message, args) => {
    if (message.author.id == botconfig.OWNERID ) {
      console.log("{Owner}")
     number = 55;
     ImageNumber = Math.floor (Math.random() * (number-1 +1)) +1;
      const embed = new Discord.MessageEmbed()
      message.channel.send("Here ya go you weeb")
     message.channel.send ({files: ["./anime/" + ImageNumber + ".jpg"]})
    }
   else{
    
    
   if (talkedRecently.has(message.author.id)) {

        message.reply("Please wait 5 seconds.");
} 
else {
    talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 5000);
        console.log(message.author.tag, "is now on a 5 second timeout")
        message.reply("This command is owner only. ")
}
}
}

module.exports.config = {
    name: "test1",
    description: "test1",
    usage: "test1",
    accessableby: "all",
    aliases: []
}
