const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
const superagent = require("superagent")
const talkedRecently = new Set();    

module.exports.run = async (bot, message, args) => {
    if (message.author.id == botconfig.OWNERID ) {
        console.log("{Owner}")
        let {body} = await superagent
        .get(`https://dog.ceo/api/breeds/image/random`)
        console.log(message.author.tag , "requested this dog url:", body.message)
        if(!{body}) return message.channel.send("Try again")
    
         const embed = new Discord.MessageEmbed()
         .addField("Dog","Here is a cute dog")
            .setImage(body.message)
            .setColor("#FF0000")
           
            
    
            return message.channel.send({embed});
    
            msg.delete();
    }
else{
    if (talkedRecently.has(message.author.id)) {

        message.reply("Please wait 5 seconds.");
} 
else {
    talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 5000);
        console.log(message.author.tag, "is now on a 5 second timeout")
    let {body} = await superagent
    .get(`https://dog.ceo/api/breeds/image/random`)
    console.log(message.author.tag , "requested this dog url:", body.message)
    if(!{body}) return message.channel.send("Try again")

     const embed = new Discord.MessageEmbed()
     .addField("Dog","Here is a cute dog")
        .setImage(body.message)
        .setColor("#FF0000")
       
        

        return message.channel.send({embed});

        msg.delete();
}
      }
    }
    

module.exports.config = {
    name: "dog",
    description: "Sends a picture of a dog!",
    usage: "!dog",
    accessableby: "Members",
    aliases: ["doggo", "puppy"]
}
