const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");
const talkedRecently = new Set();    

module.exports.run = async (bot, message, args) => {
    if (message.author.id == botconfig.OWNERID ) {
          console.log("{Owner}")
         args = message.content.substring(prefix.length).split(" ");
         let sayMessage = args.slice(1).join(' ');
          if (!args[1]) {
          return message.reply(`Please specify a message. (ex. ${prefix}message yo)`);
          }
          else{
           
          message.reply(`message was sent!(${sayMessage})`)
          console.log(`${message.author.tag} sent: ${sayMessage}`)
              }
        }
    
      
    else {
      
            if (talkedRecently.has(message.author.id)) {

     message.reply(`Please wait 10 minutes after running the command.`)} 
        else {
  
        args = message.content.substring(prefix.length).split(" ");
        let sayMessage = args.slice(1).join(' ');
        if (!args[1]) {
        return message.reply(`Please specify a message. (ex. ${prefix}message yo)`);
        }
        else{
            talkedRecently.add(message.author.id);
            setTimeout(() => {
         
               talkedRecently.delete(message.author.id);
             }, 600000);
             console.log(message.author.tag, "is now on a 10 minute timeout")
        message.reply(`message was sent!(${sayMessage})`)
        console.log(`${message.author.tag} sent: ${sayMessage}`)
}
    
}
}

}
        
  
module.exports.config = {
    name: "message",
    description: "message",
    usage: "message",
    accessableby: "all",
    aliases: []
}