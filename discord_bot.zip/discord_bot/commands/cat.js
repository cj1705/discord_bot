
const talkedRecently = new Set();    

const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");

module.exports.run = async (bot, message, args) => {
if (message.author.id == botconfig.OWNERID ) {
        console.log("{Owner}")

            try {
                get('https://aws.random.cat/meow').then(res => {
                    console.log(message.author.tag, "requested this cat url:", res.body.file)
                    const embed = new Discord.MessageEmbed()
                    .addField("Cat","Here is a cute cat")
                    .setImage(res.body.file)
                    .setColor("#FF0000")
                  
                    return message.channel.send({embed});
                });
            } catch(err) {
                return message.channel.send(err.stack);
            }
      }
else{
    if (talkedRecently.has(message.author.id)) {

        message.reply("Please wait 5 seconds.");
} 
else {
    talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 5000);
        console.log(message.author.tag, "is now on a 5 second timeout")
	if(message.content.startsWith(prefix + 'cat')) {
		try {
			get('https://aws.random.cat/meow').then(res => {
                console.log(message.author.tag, "requested this cat url:", res.body.file)
                const embed = new Discord.MessageEmbed()
                .addField("Cat","Here is a cute cat")
                .setImage(res.body.file)
                .setColor("#FF0000")
              
				return message.channel.send({embed});
			});
		} catch(err) {
			return message.channel.send(err.stack);
        }
    }
}
      }
    }


module.exports.config = {
    name: "cat",
    description: "cat",
    usage: "?cat",
    accessableby: "all",
    aliases: [],
    timeout: 10000,
}