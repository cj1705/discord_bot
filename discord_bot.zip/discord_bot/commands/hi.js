const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");
const talkedRecently = new Set();    

module.exports.run = async (bot, message, args) => {
   if (talkedRecently.has(message.author.id)) {

        message.reply("Please wait 5 seconds.");
} 
else {
    talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 5000);
        console.log(message.author.tag, "is now on a 5 second timeout")
        message.reply("Hello")
}
}
module.exports.config = {
    name: "hi",
    description: "hi",
    usage: "hi",
    accessableby: "all",
    aliases: []
}