const Discord = require("discord.js")
const botconfig = require("../botsettings.json");
let prefix = botconfig.prefix;
const { get } = require("snekfetch");

module.exports.run = async (bot, message, args) => {
  if (message.author.id == botconfig.OWNERID ) {
    console.log("{Owner}")
    let tomute = message.guild.member(message.mentions.users.first()) ||message.guild.members.cache.get(args[0])
  if(!tomute) return message.channel.send("Please tag user to mute!");
  if (tomute.id === message.author.id) return message.channel.send("You cannot mute yourself bruh");
  let muterole = message.guild.roles.cache.find(role => role.name === "Muted");  
  if(!muterole){
    try{
      muterole = await message.guild.roles.create({
        name: "Muted",
        color: "#000000",
        permissions:[]
      })
      message.guild.channels.cache.forEach(async (channel, id) => {
        await message.channel.overwritePermissions(muterole, {
            SEND_MESSAGES: false,
          ADD_REACTIONS: false
        });
      });
    }catch(e){
      console.log(e.stack);
    }
  }

  let mutetime = args[1];
  if(!mutetime) return message.channel.send("You didn't specify a time!");

  await(tomute.roles.add(muterole));
  message.reply(`<@${tomute.id}> has been muted`);

  }
  else{
   
    let tomute = message.guild.member(message.mentions.users.first()) ||message.guild.members.cache.get(args[0])
  if(!tomute) return message.channel.send("Please tag user to mute!");
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("Sorry, you don't have permissions to use this");
  if(tomute.hasPermission("MANAGE_MESSAGES")) return message.channel.send("I cant mute this user");
  if (tomute.id === message.author.id) return message.channel.send("You cannot mute yourself bruh");
  let muterole = message.guild.roles.cache.find(role => role.name === "Muted");  
  if(!muterole){
    try{
      muterole = await message.guild.roles.create({
        name: "Muted",
        color: "#000000",
        permissions:[]
      })
      message.guild.channels.cache.forEach(async (channel, id) => {
        await message.channel.overwritePermissions(muterole, {
            SEND_MESSAGES: false,
          ADD_REACTIONS: false
        });
      });
    }catch(e){
      console.log(e.stack);
    }
  }
}

  let mutetime = args[1];
  if(!mutetime) return message.channel.send("You didn't specify a time!");

  await(tomute.roles.add(muterole));
  message.reply(`<@${tomute.id}> has been muted`);

}

module.exports.config = {
    name: "mute",
    description: "mute",
    usage: "?mute",
    accessableby: "admin",
    aliases: []
}