const Discord = require("discord.js");
const interactions = require("discord-slash-commands-client");
const botsettings = require('./botsettings.json');
const { get } = require("snekfetch"); 
let prefix = botsettings.prefix;

// create a new client
const bot = new Discord.Client();
const token = "NzM0MTgwNDA1NzE2MDU4MTkz.XxN8yQ.3AfjQrHRsHyzjDZTlrl3SoErelU";

// attach the interaction client to discord.js client
bot.interactions = new interactions.Client(token, "734180405716058193");


// attach and event listener for the ready event
bot.on("ready", () => {
  console.log("Client is ready!");
  console.log(`${bot.user.username} is online`)
  bot.user.setActivity( `${prefix}help` , {type: ""});
  require("./util/eventHandler")(bot)
 console.log("Running in ",bot.guilds.cache.size,"servers");

  // Create a new command that we can test
  bot.interactions
    .createCommand({
      name: "slash",
      description: "Slash test",
    })
    .then(console.log)
    .catch(console.error);
});

// attach and event listener for the interactionCreate event
bot.on("interactionCreate", (interaction) => {
  if (interaction.name === "slash") {
    interaction.channel.send("lol this was slashy test with slash commands!" + " " + message.author.tag);
  }
});
const fs = require("fs");
bot.commands = new Discord.Collection();
bot.aliases = new Discord.Collection();

fs.readdir("./commands/", (err, files) => {
    
  if(err) console.log(err)

  let jsfile = files.filter(f => f.split(".").pop() === "js") 
  if(jsfile.length <= 0) {
       return console.log("[LOGS] Couldn't Find Commands!");
  }
  console.log("loaded:" +  " " + files)

  jsfile.forEach((f, i) => {
      let pull = require(`./commands/${f}`);
      bot.commands.set(pull.config.name, pull);  
      pull.config.aliases.forEach(alias => {
          bot.aliases.set(alias, pull.config.name)
          
      });
  });
});

bot.on("message", async message => {
  if(message.author.bot || message.channel.type === "dm") return;

  
  let messageArray = message.content.split(" ");
  let cmd = messageArray[0];
  let args = messageArray.slice(1);

  if(!message.content.startsWith(prefix)) return;
  let commandfile = bot.commands.get(cmd.slice(prefix.length)) || bot.commands.get(bot.aliases.get(cmd.slice(prefix.length)))
  if(commandfile) commandfile.run(bot,message,args)

})




bot.on("message", async message => {
if(message.author.bot || message.channel.type === "dm") return;

let prefix = botsettings.prefix;
let messageArray = message.content.split(" ")
let cmd = messageArray[0];
let args = messageArray.slice(1);

// 
//  if(cmd === `hi`){
//      console.log(message.author.tag ,"Hello")
//     return message.reply ("Hello")

//   }
// if(cmd === `e`){
//  console.log(message.author.tag ,"e")
//  return message.channel.send("e")
// }
//  if(cmd === `${prefix}Carson`){
//    return message.reply("Is good!")
// }

//if(cmd === `${prefix}channel`){
//  return message.channel.send("Here is the channel: https://www.youtube.com/channel/UCBiVFYk17t9cXZq046sITRQ")

//  }

if(cmd === `${prefix}donate`){
  return message.channel.send("Use this game to donate : https://roblox.com/games/5537023815/CarsonGames-Donation-Game")


}

if(cmd === `${prefix}website`) {
  message.channel.send("Carson Games's Website: https://www.carsongame.com")
}



if(cmd === `${prefix}specs`) {
message.channel.send("CPU: i7 3770, RAM: 16GB DDR3, GPU: RX560")

}

if(cmd === `${prefix}refresh`) {
message.channel.send("CPU: i7 3770, RAM: 16GB DDR3, GPU: RX560")

}
// If the command sent in the chat is "ping"
if(cmd === `${prefix}ping`) {

// It sends the user "Pinging"
    message.channel.send("Please wait while I test your ping.").then(m =>{
      // The math thingy to calculate the user's ping
        var ping = m.createdTimestamp - message.createdTimestamp;

      // Basic embed
        var embed = new Discord.MessageEmbed()

        .setFooter(`${message.author.tag} 's ping.`)
        .setAuthor(`Your ping is ${ping}`)
        .setColor("#FF0000")
        
        // Then It Edits the message with the ping variable embed that you created
        m.edit(embed)
        console.log(message.author.tag,`Your ping is ${ping}`)
    });
}


if(cmd === `${prefix}help`) {

  // It sends the user "Pinging"
        message.channel.send("Here are the list of commands").then(m =>{
      

          // Basic embed
            var embed = new Discord.MessageEmbed()
            .addFields(
              {name: '-----User Comamnds-----' , value:"Normal Commands" , inline: true},
              { name: '\u200B', value: '\u200B' },
              { name: `${prefix}help`, value: 'Shows this help menu.', inline: true },
              { name:  `${prefix}cat`, value: 'Shows a cute cat.', inline: true },
              { name:   `${prefix}dog`, value: 'Shows a cute dog.', inline: true },
              { name:   `${prefix}av`, value: "Shows a person you @'s avatar.", inline: true },
              { name: `${prefix}website`, value: "Sends the link to Carson Games's website.", inline: true },
              { name:`${prefix}donate`, value: 'Sends a link to donate through roblox.', inline: true },
              { name: `${prefix}ping`, value: 'Test your response time.', inline: true },
              { name: `${prefix}specs`, value: "Sends the current specs of Carson Games's PC", inline: true },
              { name: `${prefix}hi`, value: 'Sends hello back to you', inline: true },
              { name: `${prefix}message (message)`, value: 'Sends a message to Carson Games', inline: true },
              { name: `${prefix}invite `, value: 'Sends a invite link for the bot', inline: true },
              

            )
            .addFields(
             { name: '-----Mod Comamnds -----', value: 'Admin Commands'},
             { name: `${prefix}ban`, value: 'ban a user', inline: true },
             { name: `${prefix}kick`, value: 'kick a user',inline: true },
             { name: `${prefix}mute`, value: 'mute a user',inline: true },
             
            )
            .setColor("#FF0000")
        //    .addField("+help", "Shows this help menu." )
        //    .addField("+cat", "Shows a cute cat.")
        //    .addField("+dog", "Shows a cute dog.")
        //    .addField("+website","Sends the link to Carson Games's website.")
        ///    .addField("+donate", "Sends a link to donate through roblox. ")
        //    .addField("+ping", "Test your response time.")
        //    .addField("+specs", "Sends the current specs of Carson Games's PC")
        //    .addField("hi","Sends hello back to you")
        //    .setColor("#FF0000")
            // Then It Edits the message with the ping variable embed that you created
            m.edit(embed)
        });

      }
    
  
})
// login
bot.login(token);